# StudyMate Android project

This is an Android WebView wrapper for the StudyMate HTML app.

## Build APK with Android Studio
1. Install Android Studio on a computer.
2. Open this `StudyMate-Android` folder.
3. Let Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK using GitHub Actions
1. Create a new GitHub repository.
2. Upload all files and folders in this project to the repository root.
3. Open the repository's Actions tab.
4. Run **Build StudyMate APK** (or push to `main`).
5. Download the `StudyMate-debug-APK` artifact from the completed workflow.

The APK is unsigned for Play Store release, but can be installed for personal testing.
